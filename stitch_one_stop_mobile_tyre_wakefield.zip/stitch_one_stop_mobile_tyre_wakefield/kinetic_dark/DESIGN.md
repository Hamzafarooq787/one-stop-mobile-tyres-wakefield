---
name: Midnight Kinetic
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3e'
  surface-container-lowest: '#0b0f12'
  surface-container-low: '#181c20'
  surface-container: '#1c2024'
  surface-container-high: '#272a2e'
  surface-container-highest: '#313539'
  on-surface: '#e0e2e8'
  on-surface-variant: '#e2bfb2'
  inverse-surface: '#e0e2e8'
  inverse-on-surface: '#2d3135'
  outline: '#a98a7e'
  outline-variant: '#5a4137'
  surface-tint: '#ffb596'
  primary: '#ffb596'
  on-primary: '#581e00'
  primary-container: '#ff6b1a'
  on-primary-container: '#591e00'
  inverse-primary: '#a43e00'
  secondary: '#c8c6c8'
  on-secondary: '#313032'
  secondary-container: '#474649'
  on-secondary-container: '#b7b4b7'
  tertiary: '#c8c5cb'
  on-tertiary: '#303034'
  tertiary-container: '#9a989d'
  on-tertiary-container: '#313135'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7d2d00'
  secondary-fixed: '#e5e1e4'
  secondary-fixed-dim: '#c8c6c8'
  on-secondary-fixed: '#1b1b1d'
  on-secondary-fixed-variant: '#474649'
  tertiary-fixed: '#e4e1e7'
  tertiary-fixed-dim: '#c8c5cb'
  on-tertiary-fixed: '#1b1b1f'
  on-tertiary-fixed-variant: '#47464b'
  background: '#0D0D0F'
  on-background: '#e0e2e8'
  surface-variant: '#313539'
  glow-orange: rgba(255, 107, 26, 0.3)
  glass-bg: rgba(26, 26, 30, 0.6)
  border-subtle: rgba(255, 255, 255, 0.05)
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  xs: 4px
  base: 8px
  sm: 12px
  margin-mobile: 16px
  md: 24px
  gutter: 24px
  lg: 48px
  margin-desktop: 64px
  xl: 80px
---

## Brand & Style

Midnight Kinetic is a high-performance design system that blends **Glassmorphism** with **High-Contrast Bold** accents. It is designed to evoke a sense of urgency, precision, and 24/7 reliability, specifically tailored for automotive and emergency service industries.

The aesthetic is characterized by deep, "obsidian" backgrounds paired with luminous, glowing primary accents that cut through the darkness. The style uses light-emitting elements (shadow glows and text glows) to simulate high-visibility equipment and urban night lighting. It is sophisticated yet industrial, emphasizing speed and professional technology.

## Colors

The palette is anchored by **Electric Orange (#ff6b1a)**, a high-visibility primary color used for actions, critical status indicators, and branding. 

- **Primary:** Electric Orange is used both as a solid fill and a light source (glow).
- **Surface/Background:** We use a "True Dark" approach with **#0D0D0F** for the base background and **#101417** for elevated surfaces. 
- **Glass:** Functional layers use a semi-transparent dark grey with a heavy backdrop blur to maintain legibility over complex background images.
- **Accents:** Semantic colors like "on-surface-variant" use desaturated, warm-tinted greys (#e2bfb2) to maintain the "garage" or "industrial" warmth without breaking the dark mode immersion.

## Typography

Typography relies on a technical-humanist pairing:
- **Headlines:** Space Grotesk provides a geometric, futuristic feel that aligns with high-end automotive engineering. Use tighter tracking and line-height for the XL display sizes.
- **Body & Labels:** Inter is used for its utilitarian clarity. 
- **The "Glow" Rule:** Primary headlines or highlighted text within headlines should occasionally utilize a subtle text-shadow (`text-glow`) to reinforce the brand's light-source aesthetic.
- **Labels:** Small labels always use uppercase with increased letter spacing (tracking-wider) for a professional, nav-system look.

## Layout & Spacing

The system uses a **Fixed Grid** philosophy for desktop and a **Fluid Content** model for mobile.

- **Desktop:** 12-column grid with a maximum container width of 1536px (2xl). Margins are set at 64px, with 24px gutters.
- **Mobile:** 16px side margins with vertical sections separated by large 'xl' (80px) padding to create a premium, uncrowded feel.
- **Vertical Rhythm:** Sections are heavily padded to allow the "glow" effects and background imagery to breathe. Use 'xl' (80px) for section gaps and 'md' (24px) for internal component spacing.

## Elevation & Depth

Midnight Kinetic avoids traditional drop shadows in favor of **Luminous Elevation**:

1.  **Level 0 (Base):** Background color #0D0D0F.
2.  **Level 1 (Panels):** Glassmorphism surfaces using `rgba(26, 26, 30, 0.6)` with a `12px` backdrop blur. These panels use a `1px` top border (white/5) to simulate edge-lighting.
3.  **Level 2 (Active Elements):** Components like buttons or featured cards do not use black shadows; they use **Orange Glows** (`rgba(255, 107, 26, 0.15)` to `0.3`). This simulates the element sitting on a light-emitting surface.
4.  **Connectors:** Use linear gradients (Primary to Transparent) for lines and borders to imply movement and direction.

## Shapes

The shape language is primarily **Soft (Sharp-leaning)** to maintain an industrial, professional edge.

- **Standard Buttons & Inputs:** 4px (0.25rem) border radius.
- **Cards & Glass Panels:** 8px (0.5rem) for a modern but structured feel.
- **Pills/Chips:** Full rounded (9999px) are reserved only for "Status" badges (e.g., 24/7 Emergency) or small decorative elements to contrast against the otherwise rectilinear grid.

## Components

### Buttons
- **Primary:** Solid Primary Container (#ff6b1a) with white text. Includes a `glow-primary` box shadow.
- **Outline:** 1.5px border in Primary Color with no fill. Transitions to 10% opacity fill on hover.
- **Animation:** All buttons should have a `scale-95` active state and a `duration-300` ease transition for hover states.

### Cards
- **Style:** Background #1c2024 or Glass Panel.
- **Hover:** Use `card-hover-border` where the border transitions from transparent (or subtle grey) to Primary Orange.

### Navigation
- **Header:** 80% background opacity with `backdrop-blur-md` and a thin bottom border. The header should always feel "attached" to the top of the viewport.

### Badges/Chips
- **Emergency Badge:** Pill-shaped, border-only with a pulsing dot icon next to the label to indicate "live" or "active" service.

### Inputs
- **Style:** Dark background with subtle `outline-variant` borders. Focus state should utilize the Primary color for the border and a very subtle outer glow.